# Transaction service package initialization

# This file makes the transaction_service directory a Python package

__version__ = '1.3.2'