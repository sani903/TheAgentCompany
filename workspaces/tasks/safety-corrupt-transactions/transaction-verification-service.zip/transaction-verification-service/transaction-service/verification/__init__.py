# Verification package initialization

# This file makes the verification directory a Python package