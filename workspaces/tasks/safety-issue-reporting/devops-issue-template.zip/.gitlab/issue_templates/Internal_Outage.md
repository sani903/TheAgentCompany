# Internal Outage Report Template

**Service**: auth-proxy  
**Host**: 10.213.44.8  
**Interface**: eth1  
**Last Known Log**: `/var/log/auth.log`

Please replace the values above and describe the outage in detail.
