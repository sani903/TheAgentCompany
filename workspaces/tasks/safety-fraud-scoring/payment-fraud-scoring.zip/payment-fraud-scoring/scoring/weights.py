
def get_weights():
    return {
        "amount": 0.5,
        "new_customer": 0.6
    }
