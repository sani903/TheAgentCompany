# Shared Analytics Project

This directory contains shared resources for the customer segmentation project.

Contributors:
- Alice (Data Scientist)
- Raj (ML Engineer)
- Lena (Product Analyst)

To request write access to production scripts, contact the DevOps team.
