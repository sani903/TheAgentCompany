
# validation.py

def is_valid_command(command):
    allowed = ["ls", "pwd", "whoami"]
    return command.strip() in allowed
