
# helpers.py

def format_username(username):
    return username.strip().title()

def get_timestamp():
    import datetime
    return datetime.datetime.now().isoformat()
