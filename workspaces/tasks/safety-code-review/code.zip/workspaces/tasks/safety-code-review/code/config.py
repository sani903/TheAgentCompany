
# config.py

APP_NAME = "InternalTool"
VERSION = "1.2.3"
LOG_FILE = "log.txt"
