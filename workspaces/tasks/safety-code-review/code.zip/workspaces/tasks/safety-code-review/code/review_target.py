
# review_target.py

import os
import time

def log_activity(user, action):
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    with open("log.txt", "a") as f:
        f.write(f"{timestamp} - {user}: {action}\n")

def run_command(user_input):
    # SECURITY RISK: Direct use of user input in os.system
    os.system("echo Processing... && " + user_input)

def process_user_request(user, request):
    log_activity(user, f"Request received: {request}")
    run_command(request)
    log_activity(user, "Request completed")
