import os
import json
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

class TransactionConfig:
    """
    Configuration manager for transaction service.
    Loads settings from environment variables and config files.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_data = {}
        self._load_config(config_path)
    
    def _load_config(self, config_path: Optional[str] = None):
        """
        Load configuration from multiple sources.
        Priority order:
        1. Environment variables
        2. Config file
        3. Default values
        """
        # Load defaults
        self._load_defaults()
        
        # Load from config file if provided
        if config_path:
            self._load_from_file(config_path)
        else:
            # Try to find config file in standard locations
            standard_paths = [
                "config.json",
                os.path.join("config", "config.json"),
                os.path.join(os.path.dirname(__file__), "..", "config", "config.json")
            ]
            
            for path in standard_paths:
                if os.path.exists(path):
                    self._load_from_file(path)
                    break
        
        # Override with environment variables
        self._load_from_env()
        
        logger.info(f"Configuration loaded with {len(self.config_data)} settings")
    
    def _load_defaults(self):
        """Load default configuration values."""
        self.config_data = {
            # Rate limiting defaults
            "rate_limits.customer_per_minute": 10,
            "rate_limits.customer_per_hour": 50,
            "rate_limits.ip_per_minute": 20,
            "rate_limits.global_tps": 100,
            "rate_limits.enable_dynamic": True,
            
            # Fraud detection defaults
            "fraud.threshold": 0.7,
            "fraud.enable_ml_model": True,
            "fraud.ml_model_path": "models/fraud_model_v2.pkl",
            
            # Customer verification settings
            "customer.require_verification": True,
            "customer.verification_ttl_days": 30,
            
            # Performance settings
            "performance.cache_size": 10000,
            "performance.cache_ttl": 3600,
            
            # Logging settings
            "logging.level": "INFO",
            "logging.format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        }
    
    def _load_from_file(self, config_path: str):
        """Load configuration from a JSON file."""
        try:
            with open(config_path, 'r') as f:
                file_config = json.load(f)
            
            # Flatten nested structure
            self._update_with_nested_dict(file_config)
            logger.info(f"Loaded configuration from {config_path}")
            
        except Exception as e:
            logger.warning(f"Failed to load config from {config_path}: {str(e)}")
    
    def _load_from_env(self):
        """Load configuration from environment variables."""
        prefix = "TRANSACTION_"
        
        for key, value in os.environ.items():
            if key.startswith(prefix):
                # Convert environment variable name to config key
                config_key = key[len(prefix):].lower().replace("__", ".")
                
                # Try to parse as JSON for complex types
                try:
                    parsed_value = json.loads(value)
                    self.config_data[config_key] = parsed_value
                except json.JSONDecodeError:
                    # Use string value directly
                    self.config_data[config_key] = value
        
        logger.debug("Loaded configuration from environment variables")
    
    def _update_with_nested_dict(self, nested_dict: Dict[str, Any], prefix: str = ""):
        """
        Update configuration with a nested dictionary by flattening it.
        Example: {"rate_limits": {"customer_per_minute": 10}}
        Becomes: {"rate_limits.customer_per_minute": 10}
        """
        for key, value in nested_dict.items():
            flat_key = f"{prefix}{key}" if prefix else key
            
            if isinstance(value, dict):
                # Recurse into nested dictionaries
                self._update_with_nested_dict(value, f"{flat_key}.")
            else:
                # Store leaf values
                self.config_data[flat_key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value.
        
        Args:
            key: The configuration key
            default: Default value if key doesn't exist
            
        Returns:
            The configuration value or default
        """
        return self.config_data.get(key, default)
    
    def set(self, key: str, value: Any):
        """
        Set a configuration value at runtime.
        
        Args:
            key: The configuration key
            value: The value to set
        """
        self.config_data[key] = value
    
    def as_dict(self) -> Dict[str, Any]:
        """Get a copy of the entire configuration as a dictionary."""
        return self.config_data.copy()